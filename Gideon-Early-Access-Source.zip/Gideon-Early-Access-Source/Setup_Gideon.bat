@echo off
setlocal
cd /d "%~dp0"
title GIDEON Preview Setup

echo ==============================================================
echo  GIDEON EARLY ACCESS - ENVIRONMENT SETUP
echo ==============================================================
echo.
where py >nul 2>&1
if errorlevel 1 (
  echo Python's Windows launcher was not found.
  echo Install Python 3.14 from https://www.python.org/downloads/windows/
  echo Then run this setup file again.
  pause
  exit /b 1
)
py -3.14 --version >nul 2>&1
if errorlevel 1 (
  echo Python 3.14 was not found.
  echo Install Python 3.14 from https://www.python.org/downloads/windows/
  echo Then run this setup file again.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  echo Creating the virtual environment...
  py -3.14 -m venv .venv
  if errorlevel 1 goto :failed
)
echo Updating pip...
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto :failed
echo Installing Gideon dependencies...
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto :failed
if not exist data mkdir data
echo.
echo Setup complete.
echo Next, install Ollama if it is not already installed, then open PowerShell in this folder and run:
echo   ollama pull qwen2.5:7b
echo The model download is several gigabytes.
echo When it finishes, double-click Launch_Gideon_Desktop.bat.
echo.
pause
exit /b 0
:failed
echo.
echo Setup failed. Read the error above, check your internet connection, and try again.
pause
exit /b 1
