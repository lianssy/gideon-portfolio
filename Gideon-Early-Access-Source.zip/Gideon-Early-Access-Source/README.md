# Gideon — Early Access Source Preview

**This is an experimental source package, not a one-click installer.** It has been prepared for testing and learning. The app needs a Windows computer, Python 3.14, Ollama, and the `qwen2.5:7b` model.

## Requirements

- Windows 10 or Windows 11.
- Python 3.14 installed with the Python launcher (`py`). Download: https://www.python.org/downloads/windows/
- Ollama installed for Windows: https://ollama.com/download/windows
- Several gigabytes of free storage and internet access for downloading the model the first time.

## Setup

1. Extract this ZIP into a folder you control (not Program Files). Do not run it from inside the ZIP archive.
2. Double-click `Setup_Gideon.bat`. This creates a local `.venv` and installs the Python dependencies.
3. Open PowerShell in this extracted folder and run:

   ```powershell
   ollama pull qwen2.5:7b
   ```

   This downloads the model; it may take a while and uses several gigabytes of disk space.
4. When the model download finishes, double-click `Launch_Gideon_Desktop.bat`.
5. If the desktop window will not open, check whether the Microsoft Edge WebView2 Runtime is installed. Official information: https://developer.microsoft.com/microsoft-edge/webview2/

## Data

On first run, Gideon creates a `data` folder and SQLite database beside the app. This source bundle does not contain anyone's conversation database. Back up your own `data` folder before replacing or updating app code.

## What this preview does

- Local chat through Ollama and Qwen 2.5 7B.
- Saved conversations, persistent explicit memories, project/task records, and limited read-only text/code file access inside the app's project directory.
- A native desktop window wrapper using pywebview.

## Known limitations

- This is not a signed Windows installer. Python, dependencies, Ollama, and the model are installed separately.
- It is an early preview, not a hardened product. Do not rely on it for sensitive or critical decisions.
- The app reads supported text/code files from its own project directory; it does not execute those files or provide general computer control.
- If you publish changes, do not upload `.venv`, `data/gideon_memory.db`, personal chats, passwords, access tokens, or other private files.

## Troubleshooting

- If `Setup_Gideon.bat` says Python 3.14 is missing, install Python 3.14 and retry.
- If chat reports it cannot connect, make sure Ollama is installed and running, then run `ollama list`.
- If the model is missing, run `ollama pull qwen2.5:7b`.
- Do not launch both the browser and desktop versions at once; both use local port 7860.
