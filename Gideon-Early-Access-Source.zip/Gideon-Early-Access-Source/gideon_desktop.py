"""Launch the existing Gideon Gradio app in a native Windows desktop window.

Keep this file in the same folder as gideon_app.py and run it with the project's
virtual-environment Python. This wrapper does not change the UI, app database,
or Gideon's model integration.
"""
from __future__ import annotations

import sys

HOST = "127.0.0.1"
PORT = 7860
URL = f"http://{HOST}:{PORT}"


def main() -> int:
    try:
        import webview
    except ImportError:
        print("Gideon's desktop window needs pywebview.")
        print("Install it with this project's Python, then try again:")
        print(r"  .\.venv\Scripts\python.exe -m pip install pywebview")
        return 2

    try:
        import gideon_app as gideon
    except Exception as exc:
        print("Gideon could not be imported. Check that gideon_app.py is in this folder.")
        print(f"Details: {exc}")
        return 3

    try:
        # Start the same Gradio UI locally without opening a separate browser.
        gideon.demo.launch(
            server_name=HOST,
            server_port=PORT,
            share=False,
            inbrowser=False,
            prevent_thread_lock=True,
            theme=__import__("gradio").themes.Base(
                primary_hue="slate",
                secondary_hue="zinc",
                neutral_hue="zinc",
            ),
            css=gideon.CSS,
        )
    except Exception as exc:
        print(f"Gideon's local server could not start: {exc}")
        print("If Gideon is already running in a browser, stop that version with Ctrl+C first.")
        print(f"Then run this desktop launcher again. Local address: {URL}")
        return 4

    try:
        webview.create_window(
            title="GIDEON",
            url=URL,
            width=1500,
            height=940,
            min_size=(1050, 700),
            background_color="#070910",
        )
        # Let pywebview choose the available native Windows rendering backend.
        webview.start(debug=False)
    except Exception as exc:
        print(f"Gideon's desktop window could not start: {exc}")
        print("On Windows, pywebview normally uses Microsoft Edge WebView2.")
        print("Check that the WebView2 Runtime is installed, then try again.")
        return 5
    finally:
        try:
            gideon.demo.close()
        except Exception:
            pass

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
