@echo off
setlocal
cd /d "%~dp0"
title GIDEON Desktop Preview
if not exist ".venv\Scripts\python.exe" (
  echo Run Setup_Gideon.bat first.
  pause
  exit /b 1
)
where ollama >nul 2>&1
if errorlevel 1 (
  echo Ollama was not found. Install it from https://ollama.com/download/windows
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -c "import webview, gradio, requests" >nul 2>&1
if errorlevel 1 (
  echo Gideon dependencies are missing. Run Setup_Gideon.bat first.
  pause
  exit /b 1
)
ollama list | findstr /i "qwen2.5:7b" >nul 2>&1
if errorlevel 1 (
  echo The Qwen model was not found in your local Ollama models.
  echo Open PowerShell in another window and run:
  echo   ollama pull qwen2.5:7b
  pause
  exit /b 1
)
".venv\Scripts\python.exe" gideon_desktop.py
if errorlevel 1 (
  echo.
  echo Gideon exited with an error. Read the message above.
  pause
)
endlocal
